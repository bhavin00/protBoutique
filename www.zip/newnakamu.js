  // $http.post('http://localhost:3002/signin', data)
            //     .success(function (res) {
            //         if (!res.message) {
            //             //put the object in the storage
            //             localStorage.setItem('authId', res.id);
            //             localStorage.setItem('authUsername', res.username);
            //             deferred.resolve(true);

            //         } else {
            //             var error = "Username and/or password does not matched in our records";
            //             deferred.resolve(false);
            //         }
            //     })
            //     .error(function (err) {
            //         deferred.reject(err);
            //     });




              // vm.errorMsg = '';
        // vm.doLogin = function () {
        //     console.log(vm.user);
        //     sessionService.login(vm.user).then(function (res,err) {
        //         if (res) {
        //             $state.go('app.home');
        //         }
        //         else {
        //             vm.errorMsg = "Username and/or Password does not match in our records";
        //         }
        //     });
        // };
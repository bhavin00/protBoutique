angular.module('starter.dashboard', [])
    .controller('DashboardCtrl', function ($scope, $state, $ionicModal, $timeout) {
        var vm = this;
        vm.bhavin = "Dashboard";
        
    });

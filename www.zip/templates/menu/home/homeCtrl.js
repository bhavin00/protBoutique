angular.module('starter.home', [])
    .controller('HomeCtrl', function ($scope, $state, $ionicModal, $timeout) {
        var vm = this;
        vm.bhavin = "Home";
        
    });

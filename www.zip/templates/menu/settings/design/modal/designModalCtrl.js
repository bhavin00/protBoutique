angular.module('starter.designmodal', [])
    .controller('DesignModalCtrl', function ($scope, $state, $ionicModal, $stateParams, $timeout, Restangular) {

        var vm = this;
        
    
  });
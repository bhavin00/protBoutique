angular.module('starter.notifications', [])
    .controller('NotificationsCtrl', function (Restangular, $state) {
     
    });

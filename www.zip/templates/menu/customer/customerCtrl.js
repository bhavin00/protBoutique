angular.module('starter.customer', [])
    .controller('CustomerCtrl', function ($scope, $state, $ionicModal, $timeout) {
        var vm = this;
        vm.bhavin = "Customer";
        
    });

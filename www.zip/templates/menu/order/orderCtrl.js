angular.module('starter.order', [])
    .controller('OrderCtrl', function ($scope, $state, $ionicModal, $timeout) {
        var vm = this;
        vm.bhavin = "Order";
        
    });

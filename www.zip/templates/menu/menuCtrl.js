angular.module('starter.menu', [])

.controller('MenuCtrl', function($scope,$state, $ionicModal, $timeout) {
    var vm = this;
    vm.bhavin ="menu";
   
});
